# este módulo será usado para posibles configuraciones
#
# cadena conector a la base de datos
#
# Sqlite
cadena_base_datos = 'sqlite:///base001.db' 

# Mysql
# para el uso de este dialecto en SqlAlchemy
# instalar "pip install PyMySQL"
#cadena_base_datos = 'mysql+mysqlconnector://salai:12341234@localhost:3306/taller07'
